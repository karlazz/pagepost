﻿This is a text readme without any mark up.

My program is a plugin for WordPress that supports a shortcode to display a post in a page or a post.
[pagepost num=k cat=nn cat_name=mycategoryname tag=tagname order_by=DESC|ASC]

If there is a more tag in your post, the plugin will honor it.